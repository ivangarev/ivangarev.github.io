//#######################################################################################################################
//##############################################   ��������  ##################################################
//#######################################################################################################################

case BGRX_TXpremb: //������ � �����                    
   
 if (BGRXcnt == 6)
    {              
    RFOut0 = 1;    
    RFOut1 = 1;        
    }     
          
//*************    
    
 if (BGRXcnt == 12)
    {              
    RFOut0=0;   
    RFOut1=0; 
    BGRXcnt=0;
    
    ++i;     
             
    if (i >= 31)
       {
       BGRX = BGRX_TXheader;
       LedR=0;       
       }
    } 


break;
      
//***********************

case BGRX_TXheader: //������ � �����                    
             
 if (BGRXcnt >= 60)
    {              
    i=0;
    BGRX = BGRX_TXbits;                     
    BGRXcnt = 0;
    RFOut0 = 1;    
    RFOut1 = 1;            
    } 

break;

//************************************************

case BGRX_TXbits: //������ � �����                    

 if (BGRXcnt == 6)
    {              
    RFOut0=RxBuf[i];   
    RFOut1=RxBuf[i]; 
    ++i;     
             
    if (i >= 66)
       {
       BGRX = BGRX_TXguard;
       BGRXcnt = 0;        
       }
    } 

//***
    
 if (BGRXcnt == 12)
    {              
    RFOut0 = 0;    
    RFOut1 = 0;        
    }     

//***

 if (BGRXcnt == 18)
    {
    BGRXcnt= 0;              
    RFOut0 = 1;    
    RFOut1 = 1;        
    } 

break;

//************************************************                                        

case BGRX_TXguard: //������ � �����                    

 if (BGRXcnt >= 240)
    {              
    RFstate = TRFreset;
    Switch0 = 0;
    Switch1 = 0;
    LedR=0;
    } 

break;
